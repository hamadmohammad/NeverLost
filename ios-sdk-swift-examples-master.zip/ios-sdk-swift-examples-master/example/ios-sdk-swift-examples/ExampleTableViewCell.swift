//
//  ExampleTableViewCell.swift
//
//  IndoorAtlas iOS SDK Swift Examples
//

import UIKit

class ExampleTableViewCell: UITableViewCell {
    
    @IBOutlet weak var labelForExamples: UILabel!
    
    override func awakeFromNib() {
        super.awakeFromNib()
    }
    
    override func setSelected(selected: Bool, animated: Bool) {
        super.setSelected(selected, animated: animated)
    }
}

//
//  ApiKeys.swift
//
//  IndoorAtlas iOS SDK Swift Examples
//  API Keys
//

import Foundation

// API keys can be generated at <http://developer.indooratlas.com/applications>
let kAPIKey = "a74b2765-cddb-4b9b-b134-01f937b5ef6f"
let kAPISecret = "GbGGsQN7JgOQgkMz4rN9WhextVZqMm+jvK4NqILqNpmNAZw/zupvwcjeWI7JV4bU5FbS2peFnvNKJlCVp/BCBa9upuzK54vtLi6aAR5FanSQhtMTLMFsfnTfSmYUEA=="

// Floor plan id is same as "FloorplanId" at the <http://developer.indooratlas.com/venues>
let kFloorplanId = "816506a2-1e75-4dc1-8525-d5eedc2189b2"
